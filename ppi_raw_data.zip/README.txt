Relative Planetary Pressure Index - Raw Data
=================================================
Project: Sovereign Credit Rating Explorer (sovereignratings.yashmoitra.com)
Maintainer: Yash Moitra (DAEM, Cornell). ym522@cornell.edu

Files
-----
ppi_panel.csv     Country x Year panel with HDI, PHDI, MF (material footprint
                  per capita, tons), CO2_pc (production CO2 per capita, tons),
                  and PPI100 (planetary pressure index x 100). 88 countries,
                  1990-2022.
ppi_relative.csv  Same panel with leave-one-out world mean and relative
                  measures M1 (Value^2 / peer LOO), M2 (rank within peer set),
                  M4 (percentile = rank / N peers).

Methodology
-----------
The Planetary Pressure Index P is recovered from UNDP's Planetary
Pressures-Adjusted HDI definition: PHDI = HDI * (1 - P), so
P = 1 - PHDI / HDI. PPI100 reports 100*P. Higher = more environmental
pressure imposed per capita = "worse" environmental position. M1, M2, M4
are computed against the World peer set (all 88 countries with valid PHDI
for the year). Custom or preset peer-set recomputation is available
client-side on the live site.

Source
------
United Nations Development Programme. Human Development Report 2023/24:
Composite Indices Time Series. https://hdr.undp.org/data-center

License: Source data UNDP terms apply. Derived measures (M1, M2, M4) are
released under the same MIT license as the rest of the project code.
